/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LibraryLB.Containers;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author Lemmin
 */
public class MultiKeyMap<ValueType> {
    
    private Map<Object,ValueType> backingMap;
    
    private static class Alias<V>{
        Class mainType;
        V value;
    }
    public Set<Class> acceptableKeys;
    public Class mainKey;
    
    public MultiKeyMap(Map<Object,ValueType> backingMap){
        this.backingMap = backingMap;
    }
    
    public boolean contains(Object o){
        Class cls = o.getClass();
        if(cls.equals(mainKey)){
            return backingMap.containsKey(o);
        }
        if(acceptableKeys.contains(cls)){
            
        }
        return false;
        
        
    }
}
